<?php 
/**
 * Include to show a message in plugins page
 * 
 * This code is too in classes/central_server.class.php file for Ajax-Requests
 * 
 *  @uses	string	$msg_error
 */
?>
<tr class="plugin-update-tr">
	<td class="plugin-update" colspan="3">
		<div class="update-message">
			<?php echo $msg_error?>
		</div>
	</td>
</tr>