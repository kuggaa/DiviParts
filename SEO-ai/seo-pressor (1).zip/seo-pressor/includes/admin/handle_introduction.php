<?php
if( !WPPostsRateKeys_Pointers::has_ignored_tour() )
{
	include( WPPostsRateKeys::$template_dir . '/includes/tour.php');
}