<?php
/**
 * Include to show the plugin settings
 *
 * @package admin-panel
 * 
 */
// Check if user can access the list of Posts/Pages


include( WPPostsRateKeys::$plugin_dir . '/includes/admin/handle_introduction.php');
include( WPPostsRateKeys::$template_dir . '/includes/admin/handle_tutorials.php');
