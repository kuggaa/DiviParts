<?php

@set_time_limit(120);
global $wpdb;

// get global settings
$settings = WPPostsRateKeys_Settings::get_options();


$first_query = $_REQUEST['first_query'];
$keywords = array();
$title = (isset($_REQUEST['post_title'])) ? $_REQUEST['post_title'] : $_REQUEST['title'];
$content = $_REQUEST['post_content'];
$content = str_replace( "\n", "\r\n", $content ); // Simulate WP save post processing
$post_name = $_REQUEST['post_name'];

$post_args = array(
	'ID' => $post_id,
	'post_title' => $title,
	'post_content' => $content
);

// save post title, content, slug
if( $post_name != '' ) 
{
	// Update all, including Post name
	$post_args['post_name'] =  sanitize_title($post_name); // WP same processing
}
remove_action( 'save_post', array($this, 'handle_update_post_form') );
wp_update_post( $post_args );
add_action( 'save_post', array($this, 'handle_update_post_form') );


// save keywords & box settings
if( $first_query == 'false' )
{
	if( isset($_REQUEST['keywords']) && count($_REQUEST['keywords']) > 0 )
	{
		foreach( $_REQUEST['keywords'] as $kw )
		{
			$keywords[] = trim($kw);
		}
	}
	
	// update keywords if user have permission to do on page analysis
	if( WPPostsRateKeys_CustomRoles::user_can('on_page_analysis') )
	{
		WPPostsRateKeys_WPPosts_New::save_seop_box_keywords( $post_id, $keywords );
	}
	
	// update keywords if user have mission on meta/social/schema setting
	if( WPPostsRateKeys_CustomRoles::user_can('on_page_social_seo') || WPPostsRateKeys_CustomRoles::user_can('on_page_schema_setting') || WPPostsRateKeys_CustomRoles::user_can('on_page_meta_setting') )
	{
		WPPostsRateKeys_WPPosts_New::save_seop_box_settings( $post_id, $_REQUEST['settings'] );
	}
}


$keywords = WPPostsRateKeys_WPPosts_New::get_seop_box_keywords( $post_id );
$box_settings = WPPostsRateKeys_WPPosts_New::get_seop_box_settings( $post_id );



// update or reset score data
if( count($keywords) > 0 )
{
	WPPostsRateKeys_Central::check_update_post_data_in_cache_new($post_id);
}
else
{
	WPPostsRateKeys_WPPosts_New::reset_seop_analyze_result( $post_id );
}
	
@set_time_limit(30);
