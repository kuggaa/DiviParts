<script> jQuery(document).ready(function($){
$(".expand-form").click(function(){ $("#hidden-section").show(1000);
$('html, body').animate({
scrollTop: $("#hidden-section").offset().top
}, 'slow');
}); });
</script>

<script> jQuery(document).ready(function($){
$(".button-closed").click(function(){ $("#hidden-section").hide(700);
$('html, body').animate({
scrollTop: $("#hidden-section").offset().top
}, 'slow');
}); });
</script>


