<?php

/*
Plugin Name: Divi Login
Plugin URI: http://www.gritty-social.com/
Description: Custom Login for Divi Users
Version: 1.0
Author: Gritty Social
Author URI: http://www.gritty-social.com/
*/

function gs_mylogincss() {
    $dir = plugins_url('DiviLogin/login-style.css');
    echo "<link rel='stylesheet' href='{$dir}' type='text/css' media='screen' />\n";
}
add_action( 'login_enqueue_scripts', 'gs_mylogincss' );

function gs_myloginlogo() {
    $logo = ( ($user_logo = et_get_option('divi_logo')) && "" !== $user_logo ? $user_logo : get_template_directory_uri().'/images/logo.png' );
?>
    <style type="text/css">
        h1 a {
            background-image: url(<?php echo $logo;?>) !important;
        }
    </style>
<?php
}
add_action( 'login_enqueue_scripts', 'gs_myloginlogo' );

function gs_swapURL() {
    return '/';
}
add_filter('login_headerurl', 'gs_swapURL');

function gs_loginmeta() {
    return 'Home';
}
add_filter('login_headertitle', 'gs_loginmeta');

?>