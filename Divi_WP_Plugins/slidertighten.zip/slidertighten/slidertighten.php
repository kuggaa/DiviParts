<?php
/*
Plugin Name: Slider Tighten
Plugin URI: https://boltthemes.com/
Description: Slider Tighten, enhances your slider experince
Author: bolt themes
Version: 1.0
Author URI: https://boltthemes.com/
*/
require plugin_dir_path( __FILE__ ) .  '/update/update-checker.php';
$MyUpdateChecker = PucFactory::buildUpdateChecker(
    'https://boltthemes.com/updates/?action=get_metadata&slug=slidertighten',
    __FILE__, 
    'slidertighten'
);

function BT_slider_Tighten(){
	if(class_exists("ET_Builder_Module")){
		include('slidertight-module.php');
	}
}

add_action('et_builder_ready', 'BT_slider_Tighten');

function btfss_code(){ 
?>
<style type="text/css">
.et_pb_fullscreen_slider .et_pb_slides,
.et_pb_fullscreen_slider .et_pb_slide,
.et_pb_fullscreen_slider .et_pb_container {
    min-height: 100% !important;
    height: 100% !important;
}
</style>
 <script>
(function($) {
 
    $(window).on('load resize', function() {
        $('.et_pb_fullscreen_slider').each(function() {
            et_fullscreen_slider($(this));
        });
    });
 
    function et_fullscreen_slider(et_slider) {
        var et_viewport_width = $(window).width(),
            et_viewport_height = $(window).height(),
            et_slider_height = $(et_slider).find('.et_pb_slider_container_inner').innerHeight(),
            $admin_bar = $('#wpadminbar'),
            $main_header = $('#main-header'),
            $top_header = $('#top-header');
 
        $(et_slider).height('auto');
 
        if ($admin_bar.length) {
            var et_viewport_height = et_viewport_height - $admin_bar.height();
        }
 
        if ($top_header.length) {
            var et_viewport_height = et_viewport_height - $top_header.height();
        }
 
        if (!$('.et_transparent_nav').length) {
            var et_viewport_height = et_viewport_height - $main_header.height();
        }
 
        if (et_viewport_height > et_slider_height) {
            $(et_slider).height(et_viewport_height);
        }
    }
 
})(jQuery);
        </script>
<?php }

add_action( 'wp_head', 'btfss_code' );
add_action('admin_head', 'btfss_admin_css');

function btfss_admin_css() {
?>
<style>
/* Changing the module icon - the class will match your unique slug */
.et-pb-all-modules .et_pb_fullscreen_slider:before, 
.et_pb_saved_layouts_list .et_pb_fullscreen_slider:before {
	content: '\53';
}

/* Change the module color and background - the class will match your unique slug */
.et-pb-layout-buttons, .et-pb-all-modules li.et_pb_fullscreen_slider, 
.et_pb_saved_layouts_list li.et_pb_fullscreen_slider {
    background: #d76000;
    color: #fefefe;
}
.et-pb-layout-buttons:hover, .et-pb-all-modules li.et_pb_fullscreen_slider:hover, 
.et_pb_saved_layouts_list li.et_pb_fullscreen_slider:hover {
    background: #a84b00;
    color: #fefefe;
}
  </style>';
<?php }