<?php ?>

	<!DOCTYPE HTML>

	<head>
		<meta http-equiv="content-type" content="text/html" />
		<meta name="author" content="Fosker Media" />
		<link rel="stylesheet" href="<?php echo plugins_url('style.css', __FILE__); ?>" />
		<script type="text/javascript" src="<?php echo plugins_url('jquery.js', __FILE__); ?>">
		</script>
		<script type="text/javascript" src="<?php echo plugins_url('ZeroClipboard.min.js', __FILE__); ?>">
		</script>
		<title>
			Divi Section Style Manager
		</title>
		<style>
			
        .style { display: none; }
    
		</style>
	</head>

<body>
<div class="wrap">
<div class="section-style-panel">
  <ul id="logo-left">
    <li>Divi Section Style Manager</li>
  </ul>
  <ul id="out-links">
	<li><a href="http://facebook.com/foskermedia" style="color:#1e1e1e;">Facebook</a></li>
	<li><a href="mailto:hello@foskermedia.com" style="color:#1e1e1e;">Support</a></li>
  </ul>
</div>

<div class="section-style-panel">

<h1 style="text-align: center;">Welcome to the Divi Section Style Manager</h1>

<ol>

  <li>Browse the available section styles below.</li>

  <li>Click on the image of the one you'd like to use. When you click one a css class is copied to your clipboard.</li>

  <li>Paste the code into the CSS CLASS box in your sections you wish to use it on. rather simple!</li>
<li>in your section select a background colour and you are done.. rather simple!</li>
<li>PS We do not recommend using two of these in one section as together as it may confuse you website. (top + bottom or just use a Both class.)</li>
</ol>  

</div>

<div class="section-style-panel">

    <h3>Triangle Sections</h3>
	<p>Add this code to section CSS CLASS box to use the triangle section styles.</p>

		<a href="javascript:void(0);">

		<div class="style">ssm-tri-top</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/tritop1.png" class="tocopy" />

		</a>
		
		<a href="javascript:void(0);">

		<div class="style">ssm-tri-bottom</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/tribottom1.png" class="tocopy" />

		</a>
		
        <a href="javascript:void(0);">

		<div class="style">ssm-tri-both</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/triboth1.png" class="tocopy" />

		</a>		
		
        </div>	

    <div class="section-style-panel">

    <h3>Diagional Sections</h3>
	<p>Add this code to section CSS CLASS box to use the diagional section styles.</p>

		<a href="javascript:void(0);">

		<div class="style">ssm-diagonal-top</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/diagionaltop.png" class="tocopy" />

		</a>
		
		<a href="javascript:void(0);">

		<div class="style">ssm-diagonal-bottom</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/diagionalbottom.png" class="tocopy" />

		</a>
		
        <a href="javascript:void(0);">

		<div class="style">ssm-diagonal-both</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/diagionalboth.png" class="tocopy" />

		</a>		
		
        </div>	
		
		<div class="section-style-panel">

    <h3>Half Circle Sections</h3>
	<p>Add this code to section CSS CLASS box to use the half circle section styles.</p>

		<a href="javascript:void(0);">

		<div class="style">ssm-half-circle-top</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/halfcircletop.png" class="tocopy" />

		</a>
		
		<a href="javascript:void(0);">

		<div class="style">ssm-half-circle-bottom</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/halfcirclebottom.png" class="tocopy" />

		</a>
		
        <a href="javascript:void(0);">

		<div class="style">ssm-half-circle-both</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/halfcircleboth.png" class="tocopy" />

		</a>		
		
        </div>	
		
		
		
		<div class="section-style-panel">

    <h3>Round Split Sections</h3>
	<p>Add this code to section CSS CLASS box to use the round split section styles.</p>

		<a href="javascript:void(0);">

		<div class="style">ssm-rnd-split-on</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/round-split.png" class="tocopy" />

		</a>
		
		<a href="javascript:void(0);">

		<div class="style">ssm-rnd-split</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/Untitled-1.png" class="tocopy" />

		</a>
		
        		
		
        </div>
		<div class="section-style-panel">

    <h3>Angle</h3>
	<p>Add this code to section CSS CLASS box to use the Angle section styles.</p>

		<a href="javascript:void(0);">

		<div class="style">ssm-angle-left</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/angle-left.png" class="tocopy" />

		</a>
		
		<a href="javascript:void(0);">

		<div class="style">ssm-angle-right</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/angle-right.png" class="tocopy" />

		</a>
		<a href="javascript:void(0);">

		<div class="style">ssm-angle-both</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/angle-both.png" class="tocopy" />

		</a>
        		
		
        </div>
		<div class="section-style-panel">

    <h3>Sliders</h3>
	<p>Add this code to your fullwidth slider module's CSS CLASS box to either make it a fullscreen slider or a half screen slider</p>

		<a href="javascript:void(0);">

		<div class="style">ssm-fs-wh</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/fullscreenslider.png" class="tocopy" />

		</a>
		
		<a href="javascript:void(0);">

		<div class="style">ssm-hs</div>

		<img src="http://foskermedia.com/wp-content/uploads/2015/09/halfscreen.png" class="tocopy" />

		</a>
		
		
        		
		
        </div>
		

		



		

</div>
<script type="text/javascript">
			$(function() {

				$(".tocopy").each(function() {

					var ihtml = $(this).parent().find(".style").html();
					ihtml = ihtml.replace(/\n/g, '\r\n');



					var client = new ZeroClipboard($(this));



					client.on("error", function(e) {

						log("ERROR! [" + e.name + "] " + e.message);

					});



					client.on("ready", function() {

						client.on("copy", function(evt) {

							evt.clipboardData.setData("text/plain", ihtml);

						});



						client.on("aftercopy", function(e) {

							$("<div />")

							.css({

								background: 'rgba(0,0,0,0.5)',

								color: '#FFF',

								fontSize: '2em',

								position: 'fixed',

								top: (($(window).height() / 2)),

								left: ($(window).width() / 2),

								padding: '20px'

							})

							.html("Copied to clipboard!")

							.appendTo("BODY")

							.animate({

								opacity: 0

							}, 2000, function() {

								$(this).remove();

							});

						});

					});

				})

			});
		</script>
	</body>
	
	</html>