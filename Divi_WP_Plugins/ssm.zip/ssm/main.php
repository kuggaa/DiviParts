<?php

    /*

    Plugin Name: Section Styles Manager

    Plugin URI: http://www.foskermedia.com/

    Description: Section styles for the divi theme

    Author: Fosker Media
    
    Version: 1.0.1

    Author URI: http://www.foskermedia.com/

    */



function add_ssm_menu() {

    $r = plugin_dir_url( __FILE__ );

	add_menu_page( 'Section Styles Manager', 'Section Styles', 'manage_options', 'SectionStylesManager', 'ssm_options' );

}



function ssm_options() {

	if ( !current_user_can( 'manage_options' ) )  {

		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );

	}

	

    include "editor.php";

}



if ( !is_admin() ) {

    wp_register_style( 'SectionStylesManager', plugins_url('style.css', __FILE__) );

    wp_enqueue_style( 'SectionStylesManager' );

}



add_action( 'admin_menu', 'add_ssm_menu' );

?>