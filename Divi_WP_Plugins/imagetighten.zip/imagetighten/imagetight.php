<?php
/*
Plugin Name: Image Tighten
Plugin URI: https://boltthemes.com/
Description: Image tighten adds the abillity to switch images on mouseover
Author: bolt themes
Version: 1.0
Author URI: https://boltthemes.com/
*/
require plugin_dir_path( __FILE__ ) .  '/update/update-checker.php';
$MyUpdateChecker = PucFactory::buildUpdateChecker(
    'https://boltthemes.com/updates/?action=get_metadata&slug=imagetighten',
    __FILE__, 
    'imagetighten'
);

function BT_Image_Tighten(){
	if(class_exists("ET_Builder_Module")){
		include('imagetight-module.php');
	}
}

add_action('et_builder_ready', 'BT_Image_Tighten');

function BTIT_css_and_js() {

	// Front end CSS
    wp_enqueue_style('front-end-css', plugin_dir_url( __FILE__ ) . 'assets/css/frontend.css');

    // Front end JS
    wp_register_script('front-end-js', plugin_dir_url( __FILE__ ) . 'assets/js/frontend.js');

}

// Register CSS for use in WP admin - For adding colors or changing icons used in the builder. See /assets/back-end.css for example selectors...

function BTIT_admin_css() {

    // Back End CSS
    wp_enqueue_style('back-end-css', plugin_dir_url( __FILE__ ) . 'assets/css/backend.css');

}
add_action( 'wp_enqueue_scripts', 'BTIT_css_and_js' ); // Front End Assets
add_action('admin_enqueue_scripts', 'BTIT_admin_css'); // Admin Assets